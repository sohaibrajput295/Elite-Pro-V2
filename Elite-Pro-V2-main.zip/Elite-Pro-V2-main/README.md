<p align="center">
  <a href="https://chat.whatsapp.com/GRIeuAnUgk54u2IL5ujUxJ">
    <img alt=Support weight="10" src="https://telegra.ph/file/a8265ce43fbfcc43bffeb.jpg"> 
    </p>
<h1 align="center">ELITE-PRO-V2</h1>
<p align="center"> 
    </p>
<p align="center">
  <a aria-label="Join our chats" href="https://chat.whatsapp.com/GRIeuAnUgk54u2IL5ujUxJ" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Join Group chat-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
    <a align="center">
  <a aria-label="Follow Channel" href="https://whatsapp.com/channel/0029VaXaqHII1rcmdDBBsd3g" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Follow Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</a>
<a aria-label="Chat me" href="https://t.me/elitepro_md" target="_blank">
    <img alt="telegram" src="https://img.shields.io/badge/Telegram Group-24A1DE?style=for-the-badge&logo=telegram&logoColor=white" />
  </a>
</p>
      
   [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=BBDEFB&lines=WELCOME+TO+ELITE+PRO+V2+MADE+BY;CHINWO+CHINEDU+EMMANUEL;THANKS+FOR+VISITING+MY+REPO)](https://git.io/typing-svg)  
   
 ---

## DEPLOYMENT METHODS

- Click on **[FORK](https://github.com/elite-md/Elite-Pro-V2/fork)**
- Edit settings.js to your preference 
- Download zip file 🗃️

---

## FOR PANEL DEPLOYMENT

- Click on **[BOT-HOSTING.NET](https://bot-hosting.net/)**
- Create a server
- Upload zip file 🗃️ 
- Start server

---

## FOR TERMUX/SSH/UBUNTU
```
Before inputting these commands in termux... You have to extract the bot file in your internal storage. (Downloads folder)

apt update && apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
pkg install yarn
termux-setup-storage
cd /storage/emulated/0/Download/Elite-Pro-V2-main
yarn install
npm start
```
---

## FOR STARTING TERMUX AGAIN
```
cd /storage/emulated/0/Download/Elite-Pro-V2-main
npm start
```
---

## FOR 24/7 ACTIVATION TERMUX/SSH/UBUNTU
```
bash
npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
Paste this after the installation
```
---

  ## DESCRIPTION
I'm Elite-Pro a public WhatsApp bot with rich features Created by Chinwo Chinedu Emmanuel. Feel free to deploy my bot in any of the deployment site. 😜

 --- 
- Star ⭐ repo if you like this bot.
